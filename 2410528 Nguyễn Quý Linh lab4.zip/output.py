def display_students(students, courses):
    if not students:
        print("No student data available!")
        return

    for s in students:
        s.calculate_gpa(courses)
        
    sorted_students = sorted(students, key=lambda s: s.gpa, reverse=True)

    print("\n" + "="*55)
    print(f"{'ID':<10} | {'Name':<20} | {'DoB':<12} | {'GPA':<5}")
    print("="*55)
    for s in sorted_students:
        print(f"{s.id:<10} | {s.name:<20} | {s.dob:<12} | {s.gpa:.2f}")
    print("="*55)
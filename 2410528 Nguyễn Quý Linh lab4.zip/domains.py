import numpy as np

class Student:
    def init(self, student_id, name, dob):
        self.id = student_id
        self.name = name
        self.dob = dob
        self.marks = {}
        self.gpa = 0.0

    def calculate_gpa(self, courses):
        marks_list = []
        credits_list = []
        
        for course in courses:
            if course.id in self.marks:
                marks_list.append(self.marks[course.id])
                credits_list.append(course.credits)
                
        if len(credits_list) > 0 and sum(credits_list) > 0:
            marks_arr = np.array(marks_list)
            credits_arr = np.array(credits_list)
            self.gpa = np.sum(marks_arr * credits_arr) / np.sum(credits_arr)
        else:
            self.gpa = 0.0
        return self.gpa
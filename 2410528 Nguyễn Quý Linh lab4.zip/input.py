import math
from domains.student import Student
from domains.course import Course

def input_students():
    students = []
    num = int(input("Enter number of students: "))
    for i in range(num):
        print(f"\nStudent {i+1}:")
        s_id = input("ID: ").strip()
        name = input("Name: ").strip()
        dob = input("DoB (DD/MM/YYYY): ").strip()
        students.append(Student(s_id, name, dob))
    return students

def input_courses():
    courses = []
    num = int(input("Enter number of courses: "))
    for i in range(num):
        print(f"\nCourse {i+1}:")
        c_id = input("ID: ").strip()
        name = input("Name: ").strip()
        credits = int(input("Credits: ").strip())
        courses.append(Course(c_id, name, credits))
    return courses

def input_marks(students, courses):
    if not courses or not students:
        print("Please input students and courses first!")
        return

    print("\nSelect a course:")
    for idx, c in enumerate(courses):
        print(f"{idx+1}. {c.name} ({c.id}) - Credits: {c.credits}")
        
    c_id = input("Course ID: ").strip()
    course = next((c for c in courses if c.id == c_id), None)
    if not course:
        print("Invalid Course ID!")
        return

    for s in students:
        raw_mark = float(input(f"Mark for {s.name} ({s.id}): "))
        floored_mark = math.floor(raw_mark * 10) / 10
        s.marks[course.id] = floored_mark
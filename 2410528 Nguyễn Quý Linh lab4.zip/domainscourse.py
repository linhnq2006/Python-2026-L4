class Course:
    def init(self, course_id, name, credits):
        self.id = course_id
        self.name = name
        self.credits = credits
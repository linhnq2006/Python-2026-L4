import input as in_mod
import output as out_mod

def main():
    students = []
    courses = []

    while True:
        print("\nSTUDENT MARK MANAGEMENT SYSTEM (PW4)")
        print("1. Input Students")
        print("2. Input Courses")
        print("3. Input Marks")
        print("4. Show Student List sorted by GPA")
        print("0. Exit")
        
        choice = input("Your choice: ").strip()
        if choice == '1':
            students = in_mod.input_students()
        elif choice == '2':
            courses = in_mod.input_courses()
        elif choice == '3':
            in_mod.input_marks(students, courses)
        elif choice == '4':
            out_mod.display_students(students, courses)
        elif choice == '0':
            print("Exiting program...")
            break
        else:
            print("Invalid choice!")

if name == "main":
    main()